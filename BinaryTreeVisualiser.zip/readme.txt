Open home.html in any web browser.
