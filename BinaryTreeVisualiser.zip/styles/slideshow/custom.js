
// slideshow settings
$(document).ready(function() {
    $('.slideshow').cycle({
        fx: 'fade' // transition type : fade, scrollUp, shuffle, etc...
    });
	
});

 






$(document).ready( function() {

	
    Cufon.replace('.footer-one-third h2', {
        fontFamily: 'ColaborateLight', 
        fontSize: '20px', 
        color:'#cdb380'
    } );
    Cufon.replace('.footer-one-third h3', {
        fontFamily: 'ColaborateLight', 
        fontSize: '20px', 
        color:'#cdb380'
    } );
	
	
});

 

 






$(document).ready( function() {

	
    Cufon.replace('#content h1', {
        fontFamily: 'ColaborateLight', 
        fontSize: '40px', 
        color:'#000000'
    } );
    Cufon.replace('#content h2', {
        fontFamily: 'ColaborateLight', 
        fontSize: '22px', 
        color:'#000000'
    } );
    Cufon.replace('#content h3', {
        fontFamily: 'ColaborateLight', 
        fontSize: '18px', 
        color:'#000000'
    } );
    Cufon.replace('h3.post-title', {
        fontFamily: 'ColaborateLight', 
        fontSize: '30px', 
        color:'#000000'
    } );
    Cufon.replace('h2.date-header', {
        fontFamily: 'ColaborateLight', 
        fontSize: '10px', 
        color:'#000000'
    } );
	
	
    $('.rounded').corner();
	
    $('#sidebar .widget').corner();
	
});
